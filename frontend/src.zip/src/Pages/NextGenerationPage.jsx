import React from 'react'
import Transition from "./Transition";

function NextGenerationPage() {
  return (
    <div>NextGenerationPage</div>
  )
}

export default NextGenerationPage