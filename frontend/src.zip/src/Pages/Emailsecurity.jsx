import React from 'react'
import Transition from "./Transition";

function Emailsecurity() {
  return (
    <div>Emailsecurity</div>
  )
}

export default Transition(Emailsecurity);