import React from 'react'

function Blur() {
  return (
    <div className='blur-container' >
          
    </div>
  )
}

export default Blur